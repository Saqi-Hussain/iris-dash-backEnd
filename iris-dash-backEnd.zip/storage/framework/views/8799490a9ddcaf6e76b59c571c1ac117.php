<!DOCTYPE html>
<html>

<head>
    <title>Welcome to <?php echo e(config('app.name')); ?></title>
</head>

<body>
    <h1>Hello, <?php echo e($name); ?>!</h1>
    <p>Thank you for registering with us. We are excited to have you on board!</p>
    <p>If you have any questions, feel free to reply to this email.</p>
    <p>Best regards,<br><?php echo e(config('app.name')); ?> Team</p>
</body>

</html>
<?php /**PATH C:\Users\IRIS\Desktop\iris-projects\Alfla Dashboard\iris-dash-backEnd\resources\views/emails/welcome.blade.php ENDPATH**/ ?>