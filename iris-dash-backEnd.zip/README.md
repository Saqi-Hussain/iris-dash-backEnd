## Installation

-   composer install
-   composer php artisan migrate
-   php artisan serve
